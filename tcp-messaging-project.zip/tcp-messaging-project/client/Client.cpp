// Client.cpp
// Interactive chat client. Works unchanged against ServerThread, ServerSelect,
// or ServerEpoll, since all three speak the exact same framed protocol
// (protocol/framing.h). This is a deliberate design point: the concurrency
// model is entirely a server-side implementation detail.

#include <iostream>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <arpa/inet.h>
#include "../protocol/framing.h"

using namespace std;

int connectToServer(int port, char *ipAddress){
    sockaddr_in addr{};
    addr.sin_port = htons(port);
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = inet_addr(ipAddress);

    int clientSocket = socket(AF_INET, SOCK_STREAM, 0);

    if(connect(clientSocket, (sockaddr *) &addr, sizeof(addr)) < 0){
        return -1;
    }

    return clientSocket;
}

int printMenuAndGetSelection(){
    int option;
    cout << "Enter option number: " << endl;
    cout << "1. Send Message To Server" << endl;
    cout << "2. Exit" << endl;
    cin >> option;
    return (option == 1 || option == 2) ? option : 2;
}

void startChatting(int clientSocket){
    cout << "Connected To Server..." << endl;

    string message;
    int option = 1;

    while(option == 1){
        option = printMenuAndGetSelection();
        switch(option){
            case 1: {
                cout << "Enter your text to send: ";

                // ignore leftover '\n' from the previous cin >> read so
                // getline doesn't immediately consume an empty line
                cin.ignore();
                getline(cin, message);

                if(!sendMessage(clientSocket, 1, message)){
                    cout << "Error sending to the server (message too large or connection lost)!" << endl;
                    option = 2;
                    break;
                }

                auto [type, content] = recvMessage(clientSocket);
                if(type == -2){
                    cout << "Server closed the connection." << endl;
                    option = 2;
                }
                else if(type == -1){
                    cout << "Received a malformed response from server." << endl;
                }
                else if(type == 4){
                    cout << "Server: " << content << endl;
                    option = 2; // e.g. "server busy" response
                }
                else{
                    printf("From server: %s\n\n", content.c_str());
                }
                break;
            }
            default:
                cout << "Disconnecting from Server..." << endl;
                sendMessage(clientSocket, 3, "BYE");
                break;
        }
    }

    close(clientSocket);
}

int main(int argc, char *args[]){
    ignoreSigpipe();

    if(argc != 3){
        cout << "Usage: " << args[0] << " <server-ip> <port>" << endl;
        exit(1);
    }

    int port = fetchPortValue(args[2]);
    if(port == -1){
        cout << "Invalid Port Value" << endl;
        exit(1);
    }

    int clientSocket = connectToServer(port, args[1]);
    if(clientSocket == -1){
        cout << "Could not connect to Server!!" << endl;
        exit(1);
    }

    startChatting(clientSocket);

    return 0;
}
