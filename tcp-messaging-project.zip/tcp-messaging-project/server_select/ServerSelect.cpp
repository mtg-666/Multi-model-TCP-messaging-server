// ServerSelect.cpp
// Single-threaded, select()-based server. Handles many connections on one
// thread using non-blocking sockets and the incremental frame parser in
// protocol/common.h (feedClient), since a single-threaded event loop can't
// block waiting for a full message the way ServerThread.cpp can.
//
// select() is level-triggered and O(maxFd) per call (the kernel walks the
// whole fd_set every time), which is why it's included here as the
// "classic" baseline rather than the recommended production approach -
// ServerEpoll.cpp is the scalable version of the same idea.

#include <iostream>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <fcntl.h>
#include <csignal>
#include <atomic>
#include <map>
#include <vector>
#include <algorithm>
#include "../protocol/common.h"

using namespace std;

static atomic<bool> serverRunning{true};
static int listenSocket = -1;

void signalHandler(int){
    cout << "\nShutdown signal received...\n";
    serverRunning = false;
}

void setNonBlocking(int sock){
    int flags = fcntl(sock, F_GETFL, 0);
    fcntl(sock, F_SETFL, flags | O_NONBLOCK);
}

int main(int argc, char *args[]){
    if(argc != 2){
        cout << "Usage: " << args[0] << " <port>" << endl;
        exit(1);
    }
    int port = fetchPortValue(args[1]);
    if(port == -1){
        cout << "Invalid Port Value" << endl;
        exit(1);
    }

    ignoreSigpipe();
    signal(SIGINT, signalHandler);

    listenSocket = socket(AF_INET, SOCK_STREAM, 0);
    int opt = 1;
    setsockopt(listenSocket, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
    setNonBlocking(listenSocket);

    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = htonl(INADDR_ANY);

    if(::bind(listenSocket, (sockaddr*)&addr, sizeof(addr)) != 0){
        cout << "Bind failed" << endl;
        exit(1);
    }
    if(listen(listenSocket, 128) != 0){
        cout << "Listen failed" << endl;
        exit(1);
    }

    cout << "ServerSelect started at port: " << port
         << " (single-threaded, select())" << endl;

    map<int, ClientState> clients; // fd -> parser state
    int nextClientId = 1;

    while(serverRunning){
        fd_set readSet;
        FD_ZERO(&readSet);
        FD_SET(listenSocket, &readSet);
        int maxFd = listenSocket;

        for(auto &entry : clients){
            FD_SET(entry.first, &readSet);
            maxFd = max(maxFd, entry.first);
        }

        // Timeout so the loop periodically re-checks serverRunning even with
        // no activity, allowing SIGINT to actually stop the process.
        struct timeval timeout{1, 0};
        int activity = select(maxFd + 1, &readSet, nullptr, nullptr, &timeout);
        if(activity < 0){
            if(errno == EINTR) continue;
            break;
        }

        if(FD_ISSET(listenSocket, &readSet)){
            sockaddr_in clientAddr{};
            socklen_t clientLen = sizeof(clientAddr);
            int newSock = accept(listenSocket, (sockaddr*)&clientAddr, &clientLen);
            if(newSock >= 0){
                setNonBlocking(newSock);
                ClientState cs;
                cs.socket = newSock;
                cs.id = nextClientId++;
                clients[newSock] = cs;
                safePrint("New User#" + to_string(cs.id) + " connected. Active clients: " +
                           to_string(clients.size()) + "\n");
            }
        }

        vector<int> toClose;
        for(auto &entry : clients){
            int fd = entry.first;
            ClientState &cs = entry.second;
            if(!FD_ISSET(fd, &readSet)) continue;

            bool clientClosed = false;
            // Drain every fully-buffered message available right now (there
            // could be more than one queued up if the client sent several
            // small messages back to back).
            while(true){
                pair<int, string> msg;
                FeedResult res = feedClient(cs, msg);

                if(res == FeedResult::MESSAGE_READY){
                    auto [respType, respContent] = processClientMessage(msg.first, msg.second, cs.id);
                    if(respType == -1){ clientClosed = true; break; }
                    if(!sendMessage(fd, respType, respContent)){ clientClosed = true; break; }
                    continue;
                }
                else if(res == FeedResult::NEED_MORE){
                    break;
                }
                else{ // CLOSED or ERROR
                    clientClosed = true;
                    break;
                }
            }

            if(clientClosed) toClose.push_back(fd);
        }

        for(int fd : toClose){
            safePrint("User#" + to_string(clients[fd].id) + " disconnected.\n");
            close(fd);
            clients.erase(fd);
        }
    }

    cout << "Closing all connections..." << endl;
    for(auto &entry : clients) close(entry.first);
    close(listenSocket);
    cout << "Server shut down cleanly." << endl;
    return 0;
}
