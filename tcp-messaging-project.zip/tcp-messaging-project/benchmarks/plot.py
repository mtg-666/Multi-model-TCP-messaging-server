#!/usr/bin/env python3
"""
Reads benchmarks/results.csv (produced by LoadTest) and plots throughput
and p99 latency vs. concurrent connections, one line per server model.

Usage (from benchmarks/ directory):
    pip install pandas matplotlib --break-system-packages
    python3 plot.py
"""
import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("results.csv")

if df.empty:
    print("results.csv has no data rows yet - run LoadTest against each server first.")
    raise SystemExit(0)

fig, axes = plt.subplots(1, 2, figsize=(13, 5))

for label, group in df.groupby("label"):
    group = group.sort_values("connections")
    axes[0].plot(group["connections"], group["throughput_msgs_per_sec"], marker="o", label=label)
    axes[1].plot(group["connections"], group["p99_ms"], marker="o", label=label)

axes[0].set_xlabel("Concurrent connections")
axes[0].set_ylabel("Throughput (msgs/sec)")
axes[0].set_title("Throughput vs Concurrency")
axes[0].legend()
axes[0].grid(True, alpha=0.3)

axes[1].set_xlabel("Concurrent connections")
axes[1].set_ylabel("p99 latency (ms)")
axes[1].set_title("Tail Latency vs Concurrency")
axes[1].legend()
axes[1].grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig("benchmark_results.png", dpi=150)
print("Saved benchmark_results.png")
