#!/usr/bin/env bash
# Runs LoadTest against ServerThread, ServerSelect, and ServerEpoll across a
# sweep of connection counts, appending each result to benchmarks/results.csv.
#
# Usage: ./run_benchmarks.sh [port] [messages-per-connection]
# Run from the project root (after `make all`).

set -e

PORT="${1:-9000}"
MSGS_PER_CONN="${2:-20}"
CONN_COUNTS=(10 50 100 250 500 1000)
HOST="127.0.0.1"

echo "label,connections,messages_per_conn,throughput_msgs_per_sec,p50_ms,p95_ms,p99_ms,success_count,fail_count" > benchmarks/results.csv

run_server_and_sweep () {
    local BIN=$1
    local LABEL=$2

    echo "=== Benchmarking $LABEL ==="
    ./bin/"$BIN" "$PORT" > /tmp/"$LABEL"_server.log 2>&1 &
    SERVER_PID=$!
    sleep 1  # let the server bind and start listening

    for N in "${CONN_COUNTS[@]}"; do
        echo "-- $LABEL: $N connections --"
        ./bin/LoadTest "$HOST" "$PORT" "$N" "$MSGS_PER_CONN" "$LABEL"
    done

    kill -INT "$SERVER_PID" 2>/dev/null || true
    wait "$SERVER_PID" 2>/dev/null || true
    sleep 1  # let the port free up before the next server binds it
}

run_server_and_sweep ServerThread thread
run_server_and_sweep ServerSelect select
run_server_and_sweep ServerEpoll  epoll

echo ""
echo "All benchmarks complete. Results in benchmarks/results.csv"
echo "Run 'cd benchmarks && python3 plot.py' to generate benchmark_results.png"
