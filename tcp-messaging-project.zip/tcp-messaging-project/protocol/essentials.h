#pragma once
#include <string.h>
#include <string>
#include <bitset>
#include <iostream>
#include <utility>
#include <stdexcept>

// Kept from the original assignment: still used for constructing the
// logical "type $$$ content" message before it gets base64-encoded and
// wrapped in a length-prefixed frame by framing.h.
const std::string messageSeparator = "$$$###$$$";
const std::string ack = "ACK";

//--------------------------Base64 Encode Decode---------------------------------
static const std::string base64_chars =
             "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
             "abcdefghijklmnopqrstuvwxyz"
             "0123456789+/";

//given base64 encoded character, it returns the index of that character in 6 bit form
//Basically in the array of base64_chars to get the original
//6 bits position from which the character was mapped
inline std::bitset<24> getEncodingPosition(char c){
    std::bitset<24> ans;
    //if capital letters then it's simply the distance from 'A'
    if(c >= 'A' && c <= 'Z')
        ans = c-'A';
    else if(c >= 'a' && c <= 'z')//it's simply distance from 'a' + 26
        ans = 26 + c-'a';
    else if(c >= '0' && c <= '9')//it's simply distance from '0' + 52
        ans = 52 + c-'0';
    else
        ans = (c =='+' ? 62 : 63);
    return ans;
}

inline std::string encodeBase64(const std::string& str){
    std::string encodedString = "";
    std::bitset<24> threeCharGrp;
    std::bitset<24> mask = 63;
    for(size_t i = 0; i < str.size(); i++){

        if(i > 0 && i%3==0){
            //getting the first six bits and converting to base64
            encodedString.push_back(base64_chars[(((mask<<18)&threeCharGrp)>>18).to_ulong()]);

            //getting the second set of six bits and converting to base64
            encodedString.push_back(base64_chars[(((mask<<12)&threeCharGrp)>>12).to_ulong()]);

            //getting the third set of six bits and converting to base64
            encodedString.push_back(base64_chars[(((mask<<6)&threeCharGrp)>>6).to_ulong()]);

            //getting the last set of six bits and converting to base64
            encodedString.push_back(base64_chars[(mask&threeCharGrp).to_ulong()]);

            threeCharGrp.reset();
        }

        //collecting 3 bytes into threeCharGrp
        threeCharGrp <<= 8;
        threeCharGrp |= (int8_t)str[i];
    }

    if(str.size()%3 == 0){
        //remaining last three char grp
        encodedString.push_back(base64_chars[(((mask<<18)&threeCharGrp)>>18).to_ulong()]);
        encodedString.push_back(base64_chars[(((mask<<12)&threeCharGrp)>>12).to_ulong()]);
        encodedString.push_back(base64_chars[(((mask<<6)&threeCharGrp)>>6).to_ulong()]);
        encodedString.push_back(base64_chars[(mask&threeCharGrp).to_ulong()]);
    }
    else if(str.size()%3 == 2){
        //remaining group of two chars (if stringsize%3 == 2)
        threeCharGrp <<= 2;
        encodedString.push_back(base64_chars[(((mask<<12)&threeCharGrp)>>12).to_ulong()]);
        encodedString.push_back(base64_chars[(((mask<<6)&threeCharGrp)>>6).to_ulong()]);
        encodedString.push_back(base64_chars[(mask&threeCharGrp).to_ulong()]);
        encodedString.push_back('=');
    }
    else{
        //remaining group of single char (if stringsize%3 == 1)
        threeCharGrp <<= 4;
        encodedString.push_back(base64_chars[(((mask<<6)&threeCharGrp)>>6).to_ulong()]);
        encodedString.push_back(base64_chars[(mask&threeCharGrp).to_ulong()]);
        encodedString.append("==");
    }
    return encodedString;
}

inline std::string decodeBase64(std::string str){
    if(str.empty() || str.size()%4 != 0)   //every encoded string has length in multiples of 4
        return "";

    std::string decodedString = "";
    std::bitset<24> fourEncodedCharGrp;
    std::bitset<24> mask = 255;
    for(size_t i = 0; i < str.size(); i++){

        if(i > 0 && i%4==0){
            decodedString.push_back((char)(((mask<<16)&fourEncodedCharGrp)>>16).to_ulong());
            decodedString.push_back((char)(((mask<<8)&fourEncodedCharGrp)>>8).to_ulong());
            decodedString.push_back((char)((mask&fourEncodedCharGrp)).to_ulong());
            fourEncodedCharGrp.reset();
        }

        fourEncodedCharGrp <<= 6;
        fourEncodedCharGrp |= getEncodingPosition(str[i]);
    }

    //decoding last set of 4 encoded chars
    int removeBits = 0;
    if(str.back() == '='){
        fourEncodedCharGrp >>= 6;
        removeBits += 2;
        str.pop_back();
    }
    if(!str.empty() && str.back() == '='){
        fourEncodedCharGrp >>= 6;
        removeBits += 2;
        str.pop_back();
    }

    fourEncodedCharGrp >>= removeBits;

    if(removeBits == 0){
        decodedString.push_back((char)(((mask<<16)&fourEncodedCharGrp)>>16).to_ulong());
        decodedString.push_back((char)(((mask<<8)&fourEncodedCharGrp)>>8).to_ulong());
        decodedString.push_back((char)((mask&fourEncodedCharGrp)).to_ulong());
    }
    else if(removeBits == 2){
        decodedString.push_back((char)(((mask<<8)&fourEncodedCharGrp)>>8).to_ulong());
        decodedString.push_back((char)((mask&fourEncodedCharGrp)).to_ulong());
    }
    else{
        decodedString.push_back((char)((mask&fourEncodedCharGrp)).to_ulong());
    }

    return decodedString;
}

// return valid port value from args or else returns -1
inline int fetchPortValue(char *arg){
    int port = -1;
    try{
        port = std::stoi(arg);
    }catch(std::exception& e){
        std::cerr<<e.what()<<std::endl;
    }
    return (port > 0 && port < (1<<16)) ? port : -1;
}
