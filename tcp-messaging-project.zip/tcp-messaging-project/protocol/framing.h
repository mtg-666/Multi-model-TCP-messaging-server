#pragma once
// ---------------------------------------------------------------------------
// Framing layer.
//
// The original assignment code did a single read()/write() per message and
// assumed that call would return exactly one logical message. That is not
// something TCP guarantees: it is a byte stream, not a message stream. A
// single read() can return a partial message (if the sender's write hasn't
// fully arrived yet or was itself split by the kernel) or multiple messages
// glued together (if the receiver is slow to read and the kernel buffers
// several sends together).
//
// This header fixes that by wrapping every message in a simple frame:
//
//     [ 4-byte big-endian length N ][ N bytes of base64 payload ]
//
// Blocking callers (Client.cpp, ServerThread.cpp) use sendMessage()/
// recvMessage(), which loop until the exact number of bytes needed has been
// sent/received.
//
// Non-blocking callers (ServerSelect.cpp, ServerEpoll.cpp) can't block inside
// a single-threaded event loop, so they use the incremental feedClient()
// state machine in common.h instead, which is fed one readiness notification
// at a time and reassembles frames across as many partial reads as needed.
// ---------------------------------------------------------------------------

#include "essentials.h"
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <cstdint>
#include <cerrno>
#include <csignal>

// By default, writing to a socket whose peer has already closed or reset
// the connection raises SIGPIPE, and the default disposition of SIGPIPE is
// to terminate the *entire process* - not just fail that one write() call.
// Under load (many connections opening/closing rapidly) this is easy to hit
// and looks like a mysterious crash rather than a normal "connection closed"
// condition. Every binary that uses this protocol layer should call this
// once at startup so a broken pipe just makes write()/send() return -1 with
// errno == EPIPE, which sendMessage()/writeN() already handle as a normal
// (non-fatal) failure.
inline void ignoreSigpipe(){
    signal(SIGPIPE, SIG_IGN);
}

// Hard upper bound on a single frame's payload size, to stop a malicious or
// buggy peer from claiming an enormous length and exhausting memory.
const uint32_t MAX_FRAME_SIZE = 1024 * 1024; // 1 MB

// Reliably reads exactly n bytes into buf (blocking).
// Returns false on connection close or a real socket error.
inline bool readN(int sock, char *buf, size_t n){
    size_t total = 0;
    while(total < n){
        ssize_t r = read(sock, buf + total, n - total);
        if(r == 0) return false;               // peer closed connection
        if(r < 0){
            if(errno == EINTR) continue;        // interrupted syscall, retry
            return false;                        // real error
        }
        total += (size_t)r;
    }
    return true;
}

// Reliably writes exactly n bytes (blocking).
inline bool writeN(int sock, const char *buf, size_t n){
    size_t total = 0;
    while(total < n){
        ssize_t w = write(sock, buf + total, n - total);
        if(w <= 0){
            if(w < 0 && errno == EINTR) continue;
            return false;
        }
        total += (size_t)w;
    }
    return true;
}

// Encodes "type $$$ content" as base64 and sends it as
// [4-byte length][payload]. Blocking; used by Client and ServerThread.
inline bool sendMessage(int sock, int type, const std::string &content){
    std::string toEncode = std::to_string(type) + messageSeparator + content;
    std::string encoded = encodeBase64(toEncode);

    if(encoded.size() > MAX_FRAME_SIZE) return false;

    uint32_t netLen = htonl((uint32_t)encoded.size());
    if(!writeN(sock, reinterpret_cast<char*>(&netLen), sizeof(netLen))) return false;
    if(!writeN(sock, encoded.data(), encoded.size())) return false;
    return true;
}

// Receives one full frame (blocking) and decodes it back into (type, content).
//   type == -2  -> connection closed / socket error while reading
//   type == -1  -> a frame was received but failed to parse (protocol error)
//   type >= 0   -> a valid message
inline std::pair<int, std::string> recvMessage(int sock){
    uint32_t netLen;
    if(!readN(sock, reinterpret_cast<char*>(&netLen), sizeof(netLen)))
        return std::make_pair(-2, "");

    uint32_t len = ntohl(netLen);
    if(len == 0 || len > MAX_FRAME_SIZE)
        return std::make_pair(-1, "");

    std::string buf(len, '\0');
    if(!readN(sock, &buf[0], len))
        return std::make_pair(-2, "");

    std::string decoded = decodeBase64(buf);
    auto loc = decoded.find(messageSeparator);
    if(loc == std::string::npos)
        return std::make_pair(-1, "");

    int type;
    try{
        type = std::stoi(decoded.substr(0, loc));
    }catch(std::exception&){
        return std::make_pair(-1, "");
    }

    std::string content = decoded.substr(loc + messageSeparator.length());
    return std::make_pair(type, content);
}
