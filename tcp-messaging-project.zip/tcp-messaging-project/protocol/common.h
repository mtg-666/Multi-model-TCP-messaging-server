#pragma once
// ---------------------------------------------------------------------------
// Shared logic between all three server implementations:
//   - safePrint(): a mutex-guarded stdout so concurrent threads/log calls
//     don't interleave into garbled output (this was a known TODO in the
//     original code).
//   - processClientMessage(): the actual "business logic" for a message,
//     identical regardless of which I/O model received it.
//   - ClientState + feedClient(): an incremental, non-blocking frame parser
//     used by ServerSelect and ServerEpoll. Blocking servers don't need this
//     because recvMessage() in framing.h already loops until a full frame
//     arrives; non-blocking servers can't loop-and-block inside a
//     single-threaded event loop, so instead they feed whatever bytes are
//     currently available into this state machine and get told whether a
//     full message is ready yet.
// ---------------------------------------------------------------------------

#include "framing.h"
#include <mutex>
#include <vector>
#include <cstring>

inline std::mutex &coutMutex(){
    static std::mutex m;
    return m;
}

inline void safePrint(const std::string &s){
    std::lock_guard<std::mutex> lock(coutMutex());
    std::cout << s;
}

// Runs the shared per-message logic (independent of concurrency model).
// Returns the response to send back, or {-1, ""} to signal "close the
// connection" (either the client said goodbye, or sent something invalid).
inline std::pair<int, std::string> processClientMessage(int type, const std::string &content, int clientId){
    if(type == 1){
        safePrint("Client#" + std::to_string(clientId) + " says: " + content + "\n");
        return std::make_pair(2, ack);
    }
    else if(type == 3){
        safePrint("Client#" + std::to_string(clientId) + " has closed the connection\n");
        return std::make_pair(-1, "");
    }
    else{
        safePrint("Client#" + std::to_string(clientId) + " sent an unrecognized message type, closing\n");
        return std::make_pair(-1, "");
    }
}

// --------------------- Non-blocking incremental frame parser ---------------

enum class FeedResult { NEED_MORE, MESSAGE_READY, CLOSED, ERROR };

struct ClientState{
    int socket = -1;
    int id = -1;

    bool readingLength = true;
    std::vector<char> lenBuf;      // accumulates the 4-byte length header
    uint32_t expectedLen = 0;
    std::vector<char> payloadBuf;  // accumulates the frame payload
};

// Attempts to make progress parsing a single frame using whatever bytes are
// currently available on cs.socket (non-blocking). Call this in a loop from
// the caller until it returns something other than MESSAGE_READY, so that
// any messages pipelined together in one readiness notification are all
// drained (this matters especially for edge-triggered epoll, which will not
// notify again until *more* data arrives).
inline FeedResult feedClient(ClientState &cs, std::pair<int, std::string> &outMsg){

    if(cs.readingLength){
        char temp[4];
        size_t need = 4 - cs.lenBuf.size();
        ssize_t r = recv(cs.socket, temp, need, 0);
        if(r == 0) return FeedResult::CLOSED;
        if(r < 0){
            if(errno == EAGAIN || errno == EWOULDBLOCK) return FeedResult::NEED_MORE;
            if(errno == EINTR) return FeedResult::NEED_MORE; // caller will retry on next readiness
            return FeedResult::ERROR;
        }
        cs.lenBuf.insert(cs.lenBuf.end(), temp, temp + r);
        if(cs.lenBuf.size() < 4) return FeedResult::NEED_MORE;

        uint32_t netLen;
        memcpy(&netLen, cs.lenBuf.data(), 4);
        cs.expectedLen = ntohl(netLen);
        cs.lenBuf.clear();

        if(cs.expectedLen == 0 || cs.expectedLen > MAX_FRAME_SIZE)
            return FeedResult::ERROR;

        cs.readingLength = false;
        cs.payloadBuf.clear();
        cs.payloadBuf.reserve(cs.expectedLen);
    }

    while(cs.payloadBuf.size() < cs.expectedLen){
        char temp[4096];
        size_t toRead = std::min((size_t)4096, (size_t)(cs.expectedLen - cs.payloadBuf.size()));
        ssize_t r = recv(cs.socket, temp, toRead, 0);
        if(r == 0) return FeedResult::CLOSED;
        if(r < 0){
            if(errno == EAGAIN || errno == EWOULDBLOCK) return FeedResult::NEED_MORE;
            if(errno == EINTR) continue;
            return FeedResult::ERROR;
        }
        cs.payloadBuf.insert(cs.payloadBuf.end(), temp, temp + r);
    }

    // Full frame assembled: decode and reset state for the next frame.
    std::string encoded(cs.payloadBuf.begin(), cs.payloadBuf.end());
    cs.readingLength = true;
    cs.payloadBuf.clear();

    std::string decoded = decodeBase64(encoded);
    auto loc = decoded.find(messageSeparator);
    if(loc == std::string::npos) return FeedResult::ERROR;

    int type;
    try{
        type = std::stoi(decoded.substr(0, loc));
    }catch(std::exception&){
        return FeedResult::ERROR;
    }

    outMsg = std::make_pair(type, decoded.substr(loc + messageSeparator.length()));
    return FeedResult::MESSAGE_READY;
}
