// ServerEpoll.cpp
// Single-threaded, epoll()-based server using edge-triggered notification
// (EPOLLET). This is the scalable equivalent of ServerSelect.cpp: epoll
// only tells the kernel about the fds that changed state (it doesn't rescan
// every registered fd on every call like select()/poll() do), so it scales
// much better as the number of connections grows into the thousands.
//
// Edge-triggered mode requires care: epoll only notifies once when a socket
// becomes readable, so on every notification we must read (or accept) in a
// loop until we hit EAGAIN/EWOULDBLOCK, or we risk leaving data sitting in
// the kernel buffer with no future notification to tell us it's there.
// That's why both the accept loop and feedClient() loop below run to
// exhaustion on every wakeup.

#include <iostream>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/epoll.h>
#include <unistd.h>
#include <fcntl.h>
#include <csignal>
#include <atomic>
#include <unordered_map>
#include "../protocol/common.h"

using namespace std;

static atomic<bool> serverRunning{true};
static int listenSocket = -1;
static int epollFd = -1;

void signalHandler(int){
    cout << "\nShutdown signal received...\n";
    serverRunning = false;
}

void setNonBlocking(int sock){
    int flags = fcntl(sock, F_GETFL, 0);
    fcntl(sock, F_SETFL, flags | O_NONBLOCK);
}

int main(int argc, char *args[]){
    if(argc != 2){
        cout << "Usage: " << args[0] << " <port>" << endl;
        exit(1);
    }
    int port = fetchPortValue(args[1]);
    if(port == -1){
        cout << "Invalid Port Value" << endl;
        exit(1);
    }

    ignoreSigpipe();
    signal(SIGINT, signalHandler);

    listenSocket = socket(AF_INET, SOCK_STREAM, 0);
    int opt = 1;
    setsockopt(listenSocket, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
    setNonBlocking(listenSocket);

    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = htonl(INADDR_ANY);

    if(::bind(listenSocket, (sockaddr*)&addr, sizeof(addr)) != 0){
        cout << "Bind failed" << endl;
        exit(1);
    }
    if(listen(listenSocket, 128) != 0){
        cout << "Listen failed" << endl;
        exit(1);
    }

    epollFd = epoll_create1(0);
    if(epollFd < 0){
        cout << "epoll_create1 failed" << endl;
        exit(1);
    }

    epoll_event ev{};
    ev.events = EPOLLIN | EPOLLET;
    ev.data.fd = listenSocket;
    epoll_ctl(epollFd, EPOLL_CTL_ADD, listenSocket, &ev);

    cout << "ServerEpoll started at port: " << port
         << " (single-threaded, epoll edge-triggered)" << endl;

    unordered_map<int, ClientState> clients;
    int nextClientId = 1;
    const int MAX_EVENTS = 64;
    epoll_event events[MAX_EVENTS];

    while(serverRunning){
        int n = epoll_wait(epollFd, events, MAX_EVENTS, 1000); // 1s so SIGINT gets noticed
        if(n < 0){
            if(errno == EINTR) continue;
            break;
        }

        for(int i = 0; i < n; i++){
            int fd = events[i].data.fd;

            if(fd == listenSocket){
                // Edge-triggered: drain every pending connection in the
                // backlog now, since we won't get another wakeup for
                // connections that were already queued.
                while(true){
                    sockaddr_in clientAddr{};
                    socklen_t clientLen = sizeof(clientAddr);
                    int newSock = accept(listenSocket, (sockaddr*)&clientAddr, &clientLen);
                    if(newSock < 0){
                        break; // EAGAIN/EWOULDBLOCK: backlog drained, or a real error
                    }
                    setNonBlocking(newSock);

                    ClientState cs;
                    cs.socket = newSock;
                    cs.id = nextClientId++;
                    clients[newSock] = cs;

                    epoll_event cev{};
                    cev.events = EPOLLIN | EPOLLET;
                    cev.data.fd = newSock;
                    epoll_ctl(epollFd, EPOLL_CTL_ADD, newSock, &cev);

                    safePrint("New User#" + to_string(cs.id) + " connected. Active clients: " +
                               to_string(clients.size()) + "\n");
                }
                continue;
            }

            auto it = clients.find(fd);
            if(it == clients.end()) continue;
            ClientState &cs = it->second;

            bool clientClosed = false;
            // Edge-triggered: must drain fully-parsed messages AND keep
            // pulling from the socket until NEED_MORE (i.e. EAGAIN), or a
            // second message sitting right behind the first in the kernel
            // buffer could go unnoticed until unrelated future traffic.
            while(true){
                pair<int, string> msg;
                FeedResult res = feedClient(cs, msg);

                if(res == FeedResult::MESSAGE_READY){
                    auto [respType, respContent] = processClientMessage(msg.first, msg.second, cs.id);
                    if(respType == -1){ clientClosed = true; break; }
                    if(!sendMessage(fd, respType, respContent)){ clientClosed = true; break; }
                    continue;
                }
                else if(res == FeedResult::NEED_MORE){
                    break;
                }
                else{
                    clientClosed = true;
                    break;
                }
            }

            if(clientClosed){
                safePrint("User#" + to_string(cs.id) + " disconnected.\n");
                epoll_ctl(epollFd, EPOLL_CTL_DEL, fd, nullptr);
                close(fd);
                clients.erase(it);
            }
        }
    }

    cout << "Closing all connections..." << endl;
    for(auto &entry : clients) close(entry.first);
    close(listenSocket);
    close(epollFd);
    cout << "Server shut down cleanly." << endl;
    return 0;
}
