// ServerThread.cpp
// Thread-per-connection model: one OS thread handles one client for its
// entire lifetime, using blocking I/O and the length-prefixed framing
// protocol in protocol/framing.h.
//
// Fixes applied vs. the original assignment code:
//   - Correct message framing (see protocol/framing.h) instead of assuming
//     one read() == one message.
//   - globalUserCnt/activeClients are std::atomic instead of a plain int,
//     which was a data race waiting to happen the moment connection
//     acceptance moved off a single thread.
//   - SIGINT is handled for a graceful shutdown: stop accepting new
//     connections, close the listening socket, let in-flight clients finish.
//   - A concurrent-connection cap (MAX_CONCURRENT_CLIENTS) provides basic
//     backpressure so a connection flood degrades predictably (clients are
//     told the server is busy) instead of spawning unbounded threads.
//   - Log output goes through safePrint() so concurrent threads don't
//     interleave partial lines.

#include <iostream>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <thread>
#include <atomic>
#include <csignal>
#include "../protocol/common.h"

#define MAX_BACKLOG_QUEUE_LENGTH 128
#define MAX_CONCURRENT_CLIENTS 200

using namespace std;

static atomic<int> globalUserCnt{1};
static atomic<int> activeClients{0};
static atomic<bool> serverRunning{true};
static int listenSocket = -1;

void signalHandler(int){
    safePrint("\nShutdown signal received, no longer accepting new connections...\n");
    serverRunning = false;
    if(listenSocket != -1){
        // Unblocks the accept() call in main() so the loop can exit.
        shutdown(listenSocket, SHUT_RDWR);
    }
}

pair<int, sockaddr_in> startServer(int port){
    int serverSocket = socket(AF_INET, SOCK_STREAM, 0);

    int opt = 1;
    setsockopt(serverSocket, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = htonl(INADDR_ANY);

    if(::bind(serverSocket, (sockaddr *) &addr, sizeof(addr)) != 0){
        cout << "Binding failed..." << endl;
        return make_pair(-1, addr);
    }

    if(listen(serverSocket, MAX_BACKLOG_QUEUE_LENGTH) != 0){
        cout << "Failed Listening..." << endl;
        return make_pair(-1, addr);
    }

    cout << "ServerThread started at port: " << port
         << " (thread-per-connection, max " << MAX_CONCURRENT_CLIENTS << " concurrent clients)" << endl;
    return make_pair(serverSocket, addr);
}

void handleUser(int userSocket, int userID){
    activeClients++;
    safePrint("New User#" + to_string(userID) + " connected. Active clients: " +
               to_string(activeClients.load()) + "\n");

    bool closed = false;
    while(!closed){
        auto [type, content] = recvMessage(userSocket);

        if(type == -2){
            closed = true;
            break;
        }
        if(type == -1){
            safePrint("Client#" + to_string(userID) + " sent a malformed message, closing connection\n");
            closed = true;
            break;
        }

        auto [respType, respContent] = processClientMessage(type, content, userID);
        if(respType == -1){
            closed = true;
        }
        else if(!sendMessage(userSocket, respType, respContent)){
            closed = true;
        }
    }

    close(userSocket);
    activeClients--;
    safePrint("User#" + to_string(userID) + " disconnected. Active clients: " +
               to_string(activeClients.load()) + "\n");
}

void manageNewConnection(int userSocket){
    if(activeClients.load() >= MAX_CONCURRENT_CLIENTS){
        // Basic backpressure: reject cleanly instead of spawning an
        // unbounded number of threads under a connection flood.
        sendMessage(userSocket, 4, "Server busy, please try again later");
        close(userSocket);
        return;
    }
    int id = globalUserCnt++;
    thread(handleUser, userSocket, id).detach();
}

int main(int argc, char *args[]){
    if(argc != 2){
        cout << "Usage: " << args[0] << " <port>" << endl;
        exit(1);
    }

    int port = fetchPortValue(args[1]);
    if(port == -1){
        cout << "Invalid Port Value" << endl;
        exit(1);
    }

    ignoreSigpipe();
    signal(SIGINT, signalHandler);

    auto pr = startServer(port);
    if(pr.first == -1){
        cout << "Server cannot be started!!" << endl;
        exit(1);
    }

    listenSocket = pr.first;
    sockaddr_in addr = pr.second;
    socklen_t addrLen = sizeof(addr);

    while(serverRunning){
        int new_socket = accept(listenSocket, (struct sockaddr*)&addr, &addrLen);

        if(new_socket < 0){
            if(!serverRunning) break; // accept() was interrupted by shutdown()
            cout << "Failed Connection Attempt!!" << endl;
            continue;
        }

        manageNewConnection(new_socket);
    }

    close(listenSocket);
    cout << "Server shut down cleanly." << endl;
    return 0;
}
