// LoadTest.cpp
// Opens N concurrent TCP connections against a target server, sends M
// messages per connection, and measures round-trip latency and aggregate
// throughput. Used to benchmark ServerThread vs ServerSelect vs ServerEpoll
// under identical load.
//
// Usage:
//   ./LoadTest <server-ip> <port> <num-connections> <messages-per-connection> <label>
//
// Each run appends one row to benchmarks/results.csv (label, connections,
// messages_per_conn, throughput_msgs_per_sec, p50_ms, p95_ms, p99_ms,
// success_count, fail_count), which benchmarks/plot.py then reads.

#include <iostream>
#include <vector>
#include <thread>
#include <atomic>
#include <chrono>
#include <algorithm>
#include <mutex>
#include <fstream>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include "../protocol/framing.h"

using namespace std;
using namespace std::chrono;

static mutex latMutex;
static vector<double> allLatenciesMs;
static atomic<long> successCount{0};
static atomic<long> failCount{0};

int connectToServer(const char *ip, int port){
    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = inet_addr(ip);

    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if(connect(sock, (sockaddr*)&addr, sizeof(addr)) < 0){
        close(sock);
        return -1;
    }
    return sock;
}

void clientWorker(const char *ip, int port, int messagesPerClient){
    int sock = connectToServer(ip, port);
    if(sock < 0){
        failCount += messagesPerClient;
        return;
    }

    vector<double> myLatencies;
    myLatencies.reserve(messagesPerClient);

    for(int i = 0; i < messagesPerClient; i++){
        string msg = "loadtest-message-" + to_string(i);
        auto start = high_resolution_clock::now();

        if(!sendMessage(sock, 1, msg)){
            failCount++;
            continue;
        }

        auto resp = recvMessage(sock);
        auto end = high_resolution_clock::now();

        if(resp.first == 2){
            myLatencies.push_back(duration<double, milli>(end - start).count());
            successCount++;
        }
        else{
            failCount++;
        }
    }

    sendMessage(sock, 3, "BYE");
    close(sock);

    lock_guard<mutex> lock(latMutex);
    allLatenciesMs.insert(allLatenciesMs.end(), myLatencies.begin(), myLatencies.end());
}

double percentile(vector<double> &sorted, double p){
    if(sorted.empty()) return 0.0;
    size_t idx = (size_t)(p * (double)(sorted.size() - 1));
    return sorted[idx];
}

int main(int argc, char *argv[]){
    if(argc != 6){
        cout << "Usage: " << argv[0]
             << " <server-ip> <port> <num-connections> <messages-per-connection> <label>\n";
        cout << "  label identifies the server model in the CSV output, e.g. thread / select / epoll\n";
        return 1;
    }

    ignoreSigpipe();

    const char *ip = argv[1];
    int port = stoi(argv[2]);
    int numConnections = stoi(argv[3]);
    int messagesPerClient = stoi(argv[4]);
    string label = argv[5];

    cout << "Starting load test: " << numConnections << " connections x "
         << messagesPerClient << " messages each, against " << ip << ":" << port << "\n";

    auto overallStart = high_resolution_clock::now();

    vector<thread> workers;
    workers.reserve(numConnections);
    for(int i = 0; i < numConnections; i++){
        workers.emplace_back(clientWorker, ip, port, messagesPerClient);
    }
    for(auto &t : workers) t.join();

    auto overallEnd = high_resolution_clock::now();
    double totalSeconds = duration<double>(overallEnd - overallStart).count();

    sort(allLatenciesMs.begin(), allLatenciesMs.end());
    double p50 = percentile(allLatenciesMs, 0.50);
    double p95 = percentile(allLatenciesMs, 0.95);
    double p99 = percentile(allLatenciesMs, 0.99);
    double throughput = totalSeconds > 0 ? successCount / totalSeconds : 0;

    cout << "\n--- Results ---\n";
    cout << "Total time:            " << totalSeconds << " s\n";
    cout << "Successful messages:   " << successCount << "\n";
    cout << "Failed messages:       " << failCount << "\n";
    cout << "Throughput:            " << throughput << " msgs/sec\n";
    cout << "Latency p50:           " << p50 << " ms\n";
    cout << "Latency p95:           " << p95 << " ms\n";
    cout << "Latency p99:           " << p99 << " ms\n";

    // Written relative to the current working directory - the provided
    // run_benchmarks.sh always invokes LoadTest from the project root, so
    // this resolves to benchmarks/results.csv.
    ofstream csv("benchmarks/results.csv", ios::app);
    if(csv){
        csv << label << "," << numConnections << "," << messagesPerClient << ","
            << throughput << "," << p50 << "," << p95 << "," << p99 << ","
            << successCount << "," << failCount << "\n";
    }
    else{
        cout << "(warning: could not write to benchmarks/results.csv - run from the project root directory)\n";
    }

    return 0;
}
