# Personal Prep Guide — Multi-Model TCP Messaging Server

This is your own reference doc, not something you'd put in the repo. It has
three parts:

1. **Code walkthrough** — file by file, what it does and why
2. **How to run everything** — commands you should be able to type without
   thinking, including for a live demo
3. **Interview prep** — likely questions and how to answer them

Read this the night before, not the morning of. Skim it again 20 minutes
before the interview.

---

## Part 1: Code walkthrough

### File map (what changed vs. the original assignment)

| File | Status | One-line summary |
|---|---|---|
| `protocol/essentials.h` | Modified | Original base64 codec, made self-contained |
| `protocol/framing.h` | **New** | Fixes the TCP framing bug; blocking send/recv |
| `protocol/common.h` | **New** | Non-blocking incremental parser + shared logic |
| `server_thread/ServerThread.cpp` | Rewritten | Was `Server.cpp`; hardened |
| `server_select/ServerSelect.cpp` | **New** | select()-based event loop |
| `server_epoll/ServerEpoll.cpp` | **New** | epoll()-based event loop |
| `client/Client.cpp` | Modified | Uses new framing, same UX |
| `loadtest/LoadTest.cpp` | **New** | Benchmark harness |

---

### 1. The core bug this whole project is built around

Original code:
```cpp
write(sockfd, buff, strlen(buff));
read(sockfd, buff, sizeof(buff));
```

**The wrong assumption:** one `write()` = one matching `read()` on the
other side. TCP is a **byte stream**, not a message stream. The kernel can:
- **split** one write across multiple reads (large message, or receiver
  reads before all bytes arrive over the network)
- **coalesce** two writes into one read (buffering, Nagle's algorithm)

This is probably the single most common socket-programming bug people
write, and it's a very standard interview question: *"How do you know
you've received a full message over TCP?"* Answer: **you don't, unless
your protocol tells you** — fixed size, delimiter, or length prefix. I used
length prefix.

### 2. `protocol/framing.h` — the fix

Every message becomes:
```
[ 4 bytes: length N, big-endian ][ N bytes: base64 payload ]
```

```cpp
inline bool sendMessage(int sock, int type, const std::string &content){
    std::string toEncode = std::to_string(type) + messageSeparator + content;
    std::string encoded = encodeBase64(toEncode);

    uint32_t netLen = htonl((uint32_t)encoded.size());
    if(!writeN(sock, reinterpret_cast<char*>(&netLen), sizeof(netLen))) return false;
    if(!writeN(sock, encoded.data(), encoded.size())) return false;
    return true;
}
```

- `htonl` = "host to network long" — converts the 4-byte length to **big-endian
  (network byte order)** before sending. Different CPU architectures store
  multi-byte integers differently (x86 is little-endian); without this
  conversion, a length of `5` sent from one machine could be read as a huge
  number on another. Classic gotcha to mention proactively.
- `readN` / `writeN` loop until they've moved exactly N bytes, handling
  TCP's "might give you less than you asked for" behavior:

```cpp
inline bool readN(int sock, char *buf, size_t n){
    size_t total = 0;
    while(total < n){
        ssize_t r = read(sock, buf + total, n - total);
        if(r == 0) return false;               // peer closed connection
        if(r < 0){
            if(errno == EINTR) continue;        // interrupted syscall, retry
            return false;
        }
        total += (size_t)r;
    }
    return true;
}
```

Know cold:
- `read()` returning **0** = peer did an orderly shutdown (closed cleanly).
- `read()` returning **-1** = error. But `errno == EINTR` means "interrupted
  by a signal, not a real failure" — retry, don't fail.

`recvMessage()` calls `readN` twice: once for the 4-byte length, once for
that many bytes of payload. `MAX_FRAME_SIZE` (1MB) is a defensive ceiling —
without it, a peer claiming a 4GB length would make you try to allocate 4GB.
**Never trust a length field from the network without a sanity bound.**

### 3. `protocol/common.h` — the non-blocking parser (the meatiest part)

**The problem:** `ServerThread` can just call blocking `recvMessage()` and
sit there — fine, because each client has its own thread. `ServerSelect`
and `ServerEpoll` are **single-threaded** — if they blocked on one client,
the whole server freezes for everyone. So their sockets are **non-blocking**
(`fcntl(sock, F_SETFL, flags | O_NONBLOCK)`), and every read returns
immediately with whatever's available *right now* — could be zero bytes, a
partial header, a partial payload.

That means the server must **remember where it left off per client**
between event-loop iterations — a state machine:

```cpp
struct ClientState{
    int socket = -1;
    int id = -1;
    bool readingLength = true;
    std::vector<char> lenBuf;      // accumulates the 4-byte length header
    uint32_t expectedLen = 0;
    std::vector<char> payloadBuf;  // accumulates the frame payload
};
```

`feedClient()` tries to make progress from wherever it left off:

```cpp
if(cs.readingLength){
    char temp[4];
    size_t need = 4 - cs.lenBuf.size();
    ssize_t r = recv(cs.socket, temp, need, 0);
    if(r == 0) return FeedResult::CLOSED;
    if(r < 0){
        if(errno == EAGAIN || errno == EWOULDBLOCK) return FeedResult::NEED_MORE;
        ...
    }
    cs.lenBuf.insert(cs.lenBuf.end(), temp, temp + r);
    if(cs.lenBuf.size() < 4) return FeedResult::NEED_MORE;
    ...
}
```

The critical detail: **`EAGAIN`/`EWOULDBLOCK` is not an error** — on a
non-blocking socket it means "no data right now, come back later." The
function returns `NEED_MORE`, and the event loop calls `feedClient()` again
next time this socket is readable, resuming from `lenBuf`'s current state.

**One-sentence summary for the interviewer:** *"Blocking I/O lets the OS
park a thread until data arrives so you write straight-line code.
Non-blocking I/O never parks — every call returns immediately with whatever
is available — so the app has to keep its own per-connection state and
resume parsing across many small reads instead of one big blocking one."*

### 4. `server_thread/ServerThread.cpp` — hardened thread-per-connection

Changes from original:

```cpp
static atomic<int> globalUserCnt{1};
static atomic<int> activeClients{0};
```
Original used a plain `int`, safe only by accident (single-threaded
accept). `atomic<int>` guarantees the increment is indivisible — no lost
updates if multiple threads ever touch it.

```cpp
void manageNewConnection(int userSocket){
    if(activeClients.load() >= MAX_CONCURRENT_CLIENTS){
        sendMessage(userSocket, 4, "Server busy, please try again later");
        close(userSocket);
        return;
    }
    ...
}
```
Backpressure — without this cap, a connection flood spawns unbounded OS
threads (each with a real memory cost, often 8MB stack by default on
Linux). This is exactly what the benchmark caught: 2690 failed messages at
500 connections.

```cpp
void signalHandler(int){
    serverRunning = false;
    if(listenSocket != -1) shutdown(listenSocket, SHUT_RDWR);
}
```
`accept()` blocks the main loop; `shutdown()` unblocks it so the loop can
check `serverRunning` and exit instead of hanging on Ctrl+C forever. Signal
handlers should only call async-signal-safe functions — this one just sets
an atomic bool and calls `shutdown()`.

### 5. `server_select/ServerSelect.cpp` — select() mechanics

```cpp
fd_set readSet;
FD_ZERO(&readSet);
FD_SET(listenSocket, &readSet);
for(auto &entry : clients) FD_SET(entry.first, &readSet);

int activity = select(maxFd + 1, &readSet, nullptr, nullptr, &timeout);
```

`select()` takes a **fixed-size bitmask** of fds you care about, blocks
until one is ready, and **mutates the set in place** to show which ones —
that's why `readSet` is rebuilt from scratch every loop iteration.

**Why select doesn't scale (know this cold):**
1. `fd_set` has a hard ceiling on tracked fds (traditionally 1024).
2. Every call rebuilds the whole set and the kernel **scans every fd**,
   ready or not — O(total connections) per call regardless of how many are
   actually active.

The 1-second timeout isn't algorithmic — just lets the loop wake up
periodically to check `serverRunning` for clean Ctrl+C handling.

### 6. `server_epoll/ServerEpoll.cpp` — the scalable version

```cpp
epollFd = epoll_create1(0);
ev.events = EPOLLIN | EPOLLET;
epoll_ctl(epollFd, EPOLL_CTL_ADD, listenSocket, &ev);
```

Kernel maintains the interest list itself (register once via `epoll_ctl`,
not every loop). `epoll_wait()` returns only the fds that became ready —
**O(ready events)**, not O(total connections). This is why it scales where
select doesn't.

**Edge-triggered vs level-triggered — the detail most likely to trip you up:**
- **Level-triggered** (select/poll default behavior): "as long as unread
  data sits in the buffer, keep telling me every time I ask."
- **Edge-triggered** (`EPOLLET`, used here): "I notify you **once** when
  new data arrives. If you don't read it all, I will not remind you again
  until *more* new data shows up."

This is why both the accept loop and the read loop are **drain-until-EAGAIN**:

```cpp
while(true){
    int newSock = accept(listenSocket, ...);
    if(newSock < 0) break; // EAGAIN: backlog fully drained
    ...
}
```

If you only `accept()` once per notification and three connections were
queued, the other two sit there forever in edge-triggered mode. Same logic
applies to `feedClient()` being looped until `NEED_MORE`.

**Why edge-triggered at all?** Avoids the kernel re-checking readiness for
partially-drained sockets on every `epoll_wait()` call, cutting syscall
overhead at high connection counts — at the cost of requiring this strict
drain discipline in your code. Same tradeoff nginx makes.

### 7. The SIGPIPE bug — your best interview story

**What happened:** running LoadTest at 100+ concurrent connections against
ServerThread made both processes die with **exit code 141** — no error
message, truncated logs.

**Why:** `141 = 128 + 13`, signal 13 = `SIGPIPE`. If one side of a TCP
connection closes/resets, and the other side then calls `write()` on that
dead socket, POSIX's default behavior is: the kernel sends `SIGPIPE` to the
writing process, and the **default disposition of SIGPIPE is to terminate
the entire process** — not fail one call, not kill one thread. Easy to miss
in slow manual testing; easy to hit under load, where connections churn
fast enough that a write can land on a socket the peer just tore down.

**The fix:**
```cpp
inline void ignoreSigpipe(){
    signal(SIGPIPE, SIG_IGN);
}
```
Called once at startup in every binary. Now a write to a dead socket just
returns -1 with `errno == EPIPE`, which the existing error handling already
treats as "connection closed" — a normal failure path instead of a crash.

This is a **real, well-known production gotcha** — Redis, HAProxy, and
basically every serious network server explicitly handles this. Being able
to explain it unprompted is a strong signal.

### 8. `loadtest/LoadTest.cpp` — quick notes

- Each simulated client is its own OS thread doing blocking I/O —
  deliberately simple, since the load generator's job is to *produce* load,
  not to be efficient itself.
- Percentiles use the **nearest-rank method**: sort all latencies, index at
  `p * (n-1)`. It's an approximation — real production percentile
  estimation for huge datasets uses smarter structures (t-digest, etc). Fine
  to mention proactively if asked; shows you know the difference between
  "good enough for a demo" and "production-grade."

---

## Part 2: How to run everything

### One-time setup

```bash
make all
```
Builds `bin/ServerThread`, `bin/ServerSelect`, `bin/ServerEpoll`,
`bin/Client`, `bin/LoadTest`. Confirm zero warnings before the interview —
run this the night before on the actual machine you'll demo on if possible.

### Basic manual test

Terminal 1:
```bash
./bin/ServerThread 9000
```

Terminal 2:
```bash
./bin/Client 127.0.0.1 9000
```
Type `1`, enter a message, see the ACK. Type `2` to disconnect cleanly.

### Swap servers without touching the client

Ctrl+C terminal 1 (watch it print a graceful shutdown message), then:
```bash
./bin/ServerSelect 9000    # or ServerEpoll
```
Reconnect the same client — works unmodified. This is your best "look, the
protocol is decoupled from the concurrency model" demo moment.

### Quick load test

```bash
./bin/LoadTest 127.0.0.1 9000 50 10 demo
```
`50` connections, `10` messages each, labeled `demo`. Prints throughput and
p50/p95/p99 latency, appends a row to `benchmarks/results.csv`.

### Full benchmark sweep (don't run this live — takes a while)

```bash
./run_benchmarks.sh 9000 15
cd benchmarks && python3 plot.py
```
Produces `benchmark_results.png`. **Have this image already generated and
open before the interview** — don't run the full sweep in front of someone,
it's slow and depends on machine load, which makes for awkward silence.

### Cleanup / troubleshooting

If a port's stuck from a previous test:
```bash
pkill -f ServerThread; pkill -f ServerSelect; pkill -f ServerEpoll
```
Run this before you start demoing, so a leftover process doesn't cause
`bind failed` in front of the interviewer. Keep a second port number
(`9001`) ready to type without thinking if `9000` is stuck.

### Demo flow if given ~5-8 minutes

1. **30 sec** — orient: "found a real TCP framing bug in a lab assignment,
   fixed it, extended it into three interchangeable concurrency models,
   benchmarked them."
2. **1-2 min** — basic correctness: server + client, message + ACK.
3. **1 min** — swap ServerThread → ServerEpoll, same client reconnects,
   works unmodified. Say explicitly why that's the point.
4. **2 min** — the SIGPIPE story (see below on whether to reproduce live).
5. **1-2 min** — show the benchmark graph (pre-generated), walk through
   what it shows and why.

**On reproducing SIGPIPE live:** only do this if you've rehearsed it and
kept a deliberately-unfixed build around (`bin_buggy/`, built by commenting
out `ignoreSigpipe()`) so you're not surprised by *how* it fails. If you're
not fully confident, it's completely fine to say "I hit this during
testing — let me show you in the code rather than risk reproducing a crash
live," and go straight to the `signal(SIGPIPE, SIG_IGN)` line. Either way
works; pick based on your comfort level, not out of a sense you "must" do
it live.

### If something breaks live

Don't panic-debug in front of the interviewer. Say "let me show you this in
the code and the saved results instead" and pivot to `framing.h` or the
benchmark graph. A calm pivot reads as more senior than a flawless demo.

---

## Part 3: Interview Q&A

### Protocol / framing

**Q: How do you know when you've received a full message over TCP?**
A: You don't, unless your protocol tells you — TCP is a byte stream with no
built-in message boundaries. Options: fixed-size messages, a delimiter, or
a length prefix. I used a 4-byte length prefix before each frame.

**Q: Why does the length need to be converted with htonl?**
A: Different CPU architectures store multi-byte integers in different byte
orders (x86 is little-endian). `htonl` converts to a fixed network byte
order (big-endian) so both ends agree on how to interpret the bytes,
regardless of what machine either side runs on.

**Q: What's the difference between read() returning 0 vs -1?**
A: 0 means the peer performed an orderly shutdown — a clean close, not an
error. -1 means an actual error occurred; check `errno` — e.g. `EINTR`
means the syscall was interrupted by a signal and should just be retried,
not treated as a failure.

**Q: Why cap the frame size at 1MB?**
A: The length prefix is attacker/bug-controlled input from the network.
Without a sanity ceiling, a peer claiming an enormous length could force the
receiver to allocate huge buffers. Never trust a length field off the wire
without a bound.

### Concurrency models

**Q: Why does thread-per-connection degrade under load?**
A: Every connection costs a full OS thread — memory (default stack size is
often 8MB on Linux), thread creation overhead, and scheduler bookkeeping.
Past some connection count, the OS scheduler itself becomes the bottleneck,
not the actual work being done. My benchmark showed real failures (not just
slowdowns) starting at 250 connections.

**Q: select() vs poll() vs epoll()?**
A: select() uses a fixed-size bitmask (traditionally 1024 fds) and the
kernel rescans the *entire* set every call — O(n) regardless of how many
fds are actually ready. poll() removes the fixed-size limit but still
rescans everything — still O(n). epoll() has the kernel maintain the
interest list persistently (register once via epoll_ctl) and only returns
the fds that actually became ready — O(ready events), which is why it
scales to far more connections.

**Q: Edge-triggered vs level-triggered epoll?**
A: Level-triggered keeps notifying you as long as unread data sits in the
buffer — simple, forgiving. Edge-triggered notifies exactly once when new
data arrives and won't remind you again until more new data shows up — so
you must fully drain a socket (read until EAGAIN) on every notification, or
risk data sitting unnoticed. I use edge-triggered, which is why both my
accept loop and read loop run to exhaustion on every wakeup.

**Q: When would you pick thread-per-connection vs an event loop?**
A: Thread-per-connection is simpler to reason about (straight-line blocking
code) and fine for low/moderate connection counts, especially if each
connection does meaningful CPU work. Event loops win when you have many
mostly-idle connections — chat servers, long polling, proxies — where the
cost is dominated by connection *count* rather than per-connection work.

### Debugging / the SIGPIPE bug

**Q: Tell me about a bug you found and fixed.**
A: Walk through the SIGPIPE story — reproduce symptom (exit 141, silent
crash under load) → root cause (default SIGPIPE disposition kills the whole
process on write-to-closed-socket) → fix (`signal(SIGPIPE, SIG_IGN)`) → why
it's easy to miss in low-concurrency testing and easy to hit under load.

**Q: How did you find it?**
A: Load-testing at higher concurrency than manual testing ever exercised —
it only showed up once connections were actually being torn down mid-write,
which realistic load produces but a single manual client/server session
doesn't.

### Design / tradeoffs

**Q: Why length-prefix instead of a delimiter like \n?**
A: A delimiter requires scanning byte-by-byte and breaks if the payload
could contain that byte itself (needs escaping). Length-prefix tells the
receiver exactly how many bytes to read with no scanning or escaping — the
cost is the sender needing to know the length upfront, which is free here
since messages are fully buffered before sending.

**Q: What would you change/add if you had more time?**
A: A few honest answers: (1) TLS on top of the same framing layer, (2) a
thread pool instead of unbounded detached threads for ServerThread, (3)
proper percentile estimation (t-digest) for LoadTest instead of nearest-rank
on a fully sorted array, which doesn't scale to huge sample counts, (4)
running the benchmark on real hardware at higher connection counts (1000s)
since the crossover point shown here is from a resource-limited environment.

**Q: What are the limits of your benchmark?**
A: Single local run, loopback only (no real network latency/loss), small
text messages, limited connection range. The crossover point I found is
illustrative of the qualitative behavior, not a universal number — I'd want
to re-run on dedicated hardware with a wider sweep before treating specific
numbers as authoritative.
